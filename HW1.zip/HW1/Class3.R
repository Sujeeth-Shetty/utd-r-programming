library(data.table)
library(mlbench)
data(BostonHousing)
summary(BostonHousing)
housing.df <- BostonHousing
summary(housing.df)
dim(housing.df)
str(BostonHousing)

housing.dt <- setDT(BostonHousing)

str(housing.dt)
housing.dt[,.(mean(medv))] #taking mean of 

is.na(housing.df$medv) #how many variables

sum(is.na(housing.df$medv)) 

sum(!is.na(housing.df$medv)) #hoe many non missing

housing.dt[, num_no_miss_vars := rowsum]

#melt and cast for pivot table 

#dummy varibale-> 
#cat                  dummy(1)   dummy(2)
#1                      1
#2                      0
#1                     1  
#3                     0
#4
#5
#6

#here row the sum become 1 this is called Multicollinality
#so to avoid that we need to drop one column. m-> m-1 dummies

cereals <- read.csv("D:/R/Cereals.csv")
summary(cereals)
str(cereals)
